# 🔍 PHÂN TÍCH GAP: MODULE 1 & 2

## MODULE 1: MARKET TIMING

### So sánh chi tiết

| Tính năng | Hiện tại (v2) | Mục tiêu (v3) | Gap | Ưu tiên |
|-----------|---------------|---------------|-----|---------|
| **PRICE ANALYSIS** |
| Price vs MA | ✅ Có (MA20, MA50) | ✅ Giữ nguyên | - | - |
| MA Alignment | ✅ Có (MA20 > MA50) | ✅ Thêm MA200 | Nhỏ | 🟢 |
| **Trend Slope** | ❌ Không có | ⭐ Linear Regression slope | **LỚN** | 🔴 |
| **Percentile Rank** | ❌ Không có | ⭐ Vị thế giá trong N ngày | **LỚN** | 🔴 |
| **TECHNICAL INDICATORS** |
| RSI Value | ✅ Có | ✅ Giữ nguyên | - | - |
| **RSI Regime** | ❌ Chỉ check >70/<30 | ⭐ RSI_Min/Max 50 phiên | **LỚN** | 🔴 |
| MACD Histogram | ✅ Có (+/-) | ✅ Giữ nguyên | - | - |
| **MACD Impulse** | ❌ Không có | ⭐ Histogram tăng/giảm | Trung bình | 🟡 |
| ADX Value | ✅ Có | ✅ Giữ nguyên | - | - |
| **ADX Divergence** | ❌ Không có | ⭐ ADX vs Price divergence | Trung bình | 🟡 |
| **VOLUME PROFILE** |
| POC | ✅ Có | ✅ Giữ nguyên | - | - |
| VAH/VAL | ✅ Có | ✅ Giữ nguyên | - | - |
| HVN/LVN | ✅ Có | ✅ Giữ nguyên | - | - |
| VP Signals | ✅ Có | ✅ Giữ nguyên | - | - |
| **MARKET INTERNALS** |
| Breadth (A/D) | ✅ Có (estimate) | ⭐ Dữ liệu thực | Trung bình | 🟡 |
| **Distribution Days** | ❌ Không có | ⭐ Đếm trong 25 phiên | **LỚN** | 🔴 |
| **Follow-Through Day** | ❌ Không có | ⭐ Phát hiện FTD | **LỚN** | 🔴 |
| **MONEY FLOW** |
| Foreign Net | ✅ Có (placeholder) | ⭐ Dữ liệu thực | Trung bình | 🟡 |
| **Cumulative Foreign** | ❌ Không có | ⭐ Tích lũy 20 ngày | **LỚN** | 🔴 |
| **Proprietary** | ❌ Không có | ⭐ Dữ liệu tự doanh | Trung bình | 🟡 |
| **OUTPUT** |
| Market Color | ✅ Có (3 màu) | ✅ Giữ nguyên | - | - |
| Market Score | ✅ Có (0-100) | ⭐ Cải tiến công thức | Nhỏ | 🟢 |
| **Market Regime** | ❌ Không có | ⭐ Accumulation/Distribution | **LỚN** | 🔴 |
| **Traffic Light Logic** | ✅ Đơn giản | ⭐ Theo IBD model | Trung bình | 🟡 |

### Tóm tắt Module 1

- **Đã có:** 60%
- **Cần thêm:** 40%
- **Gap lớn nhất:**
  1. Distribution Day counting
  2. Follow-Through Day detection
  3. Trend Slope (MA slope)
  4. RSI Regime analysis
  5. Cumulative Money Flow

---

## MODULE 2: SECTOR ROTATION

### So sánh chi tiết

| Tính năng | Hiện tại (v2) | Mục tiêu (v3) | Gap | Ưu tiên |
|-----------|---------------|---------------|-----|---------|
| **SECTOR DATA** |
| Sector Indices | ✅ Có (9 ngành) | ✅ Giữ nguyên | - | - |
| Performance 1D/5D/1M/3M | ✅ Có | ✅ Giữ nguyên | - | - |
| **RELATIVE STRENGTH** |
| RS vs VNIndex | ✅ Có (đơn giản) | ⭐ Cải tiến weighted | Nhỏ | 🟢 |
| **RS Rating IBD-style** | ❌ Không có | ⭐ Percentile rank toàn thị trường | **LỚN** | 🔴 |
| **SECTOR ANALYSIS** |
| Phase Classification | ✅ Có (4 phases) | ✅ Giữ nguyên + cải tiến | Nhỏ | 🟢 |
| Composite Score | ✅ Có | ⭐ Cải tiến trọng số | Nhỏ | 🟢 |
| **Rotation Clock** | ❌ Không có | ⭐ Early/Mid/Late Cycle | **LỚN** | 🔴 |
| **Cyclical/Defensive** | ❌ Không có | ⭐ Phân loại ngành | Trung bình | 🟡 |
| **MONEY FLOW** |
| Sector Volume | ✅ Có (volume ratio) | ✅ Giữ nguyên | - | - |
| **Sector Foreign Flow** | ❌ Không có | ⭐ Khối ngoại theo ngành | **LỚN** | 🔴 |
| **Sector CMF** | ❌ Không có | ⭐ Chaikin MF theo ngành | Trung bình | 🟡 |
| **STOCK LEVEL** |
| Top Gainers/Losers | ✅ Có | ✅ Giữ nguyên | - | - |
| **Leader Stocks** | ❌ Chưa chi tiết | ⭐ Top 5 mã mỗi ngành + metrics | **LỚN** | 🔴 |
| **Volume Profile ngành** | ✅ Có (cơ bản) | ⭐ VP cho sector index | Nhỏ | 🟢 |
| **OUTPUT** |
| Ranking Table | ✅ Có | ✅ Giữ nguyên | - | - |
| Phase Summary | ✅ Có | ✅ Giữ nguyên | - | - |
| **Rotation Recommendations** | ❌ Đơn giản | ⭐ Chi tiết: Tăng/Giữ/Giảm | Trung bình | 🟡 |

### Tóm tắt Module 2

- **Đã có:** 55%
- **Cần thêm:** 45%
- **Gap lớn nhất:**
  1. RS Rating IBD-style
  2. Sector Rotation Clock
  3. Sector Foreign Flow
  4. Leader Stocks chi tiết

---

## 🎯 PRIORITY MATRIX

```
                    IMPACT
                    High │ Medium │ Low
            ┌───────────┼────────┼───────┐
      High  │ 🔴 DO     │ 🟡 PLAN│ 🟢 NICE│  EFFORT
            │ FIRST     │        │ TO HAVE│
            ├───────────┼────────┼───────┤
      Medium│ 🟡 PLAN   │ 🟢 NICE│ ⚪ SKIP │
            │           │ TO HAVE│        │
            ├───────────┼────────┼───────┤
      Low   │ 🟢 QUICK  │ ⚪ SKIP │ ⚪ SKIP │
            │ WIN       │        │        │
            └───────────┴────────┴───────┘
```

### 🔴 DO FIRST (High Impact, Any Effort)

**Module 1:**
1. Distribution Day counting - Core IBD concept
2. Follow-Through Day detection - Xác nhận đáy
3. Trend Slope (Linear Regression) - Context quan trọng nhất
4. RSI Regime - Tránh false signal ở RSI

**Module 2:**
1. RS Rating IBD-style - Ranking chính xác
2. Sector Foreign Flow - Smart money tracking
3. Leader Stocks extraction - Output actionable

### 🟡 PLAN (Medium Priority)

**Module 1:**
- MACD Impulse System
- ADX Divergence
- Cumulative Money Flow
- Traffic Light cải tiến

**Module 2:**
- Rotation Clock (Economic cycle)
- Cyclical/Defensive classification
- Sector CMF

### 🟢 NICE TO HAVE

- MA200 alignment
- Percentile Rank
- VP cải tiến
- Minor scoring adjustments

---

## 📋 CHECKLIST IMPLEMENTATION

### Module 1 v3 - Market Timing

```
□ DATA CONTEXT LAYER
  □ calc_trend_slope() - Linear regression on MA
  □ calc_percentile_rank() - Price position in N days
  □ calc_rsi_regime() - RSI min/max 50 days
  □ calc_macd_impulse() - Histogram direction

□ DISTRIBUTION ANALYSIS
  □ count_distribution_days() - Last 25 sessions
  □ is_distribution_day() - Price down + Vol up
  □ get_distribution_status() - Count vs threshold

□ FOLLOW-THROUGH DAY
  □ find_recent_low() - Bottom detection
  □ detect_ftd() - Day 4-10, +1.25%, Vol up
  □ validate_ftd() - Confirmation rules

□ MARKET REGIME
  □ classify_regime() - Accumulation/Markup/Distribution/Markdown
  □ get_regime_signals() - Specific signals per regime

□ TRAFFIC LIGHT v2
  □ calc_green_conditions() - All criteria for GREEN
  □ calc_yellow_conditions() - Warning criteria
  □ calc_red_conditions() - Danger criteria
  □ get_traffic_light() - Final decision

□ OUTPUT ENHANCEMENT
  □ Add trend slope to report
  □ Add distribution day count
  □ Add FTD status
  □ Add regime classification
```

### Module 2 v3 - Sector Rotation

```
□ RS RATING IBD-STYLE
  □ calc_quarterly_performance() - Q1, Q2, Q3, Q4
  □ calc_weighted_rs() - 40/30/20/10 weighting
  □ rank_vs_universe() - Percentile against all stocks
  □ get_rs_rating() - 1-99 scale

□ SECTOR MONEY FLOW
  □ get_sector_foreign_data() - vnstock API
  □ calc_cumulative_net() - 20-day cumulative
  □ calc_sector_cmf() - Chaikin MF for sector
  □ get_flow_signal() - Accumulation/Distribution

□ ROTATION CLOCK
  □ classify_economic_cycle() - Based on sector leaders
  □ get_cycle_phase() - Early/Mid/Late/Recession
  □ get_sector_recommendations() - Per cycle phase

□ LEADER STOCKS
  □ get_top_stocks_per_sector() - Top 5 by RS
  □ enrich_stock_data() - Add fundamentals
  □ filter_by_criteria() - CANSLIM filters
  □ output_leader_table() - Formatted output

□ OUTPUT ENHANCEMENT
  □ Add RS Rating column
  □ Add Money Flow column
  □ Add Cycle Phase
  □ Add Leader Stocks section
```

---

## 🚀 NEXT STEPS

**Câu hỏi cho bạn:**

1. **Bắt đầu từ đâu?**
   - Option A: Module 1 v3 hoàn chỉnh trước
   - Option B: Module 2 v3 hoàn chỉnh trước
   - Option C: Data Context Layer (dùng chung) trước

2. **Dữ liệu thực:**
   - vnstock premium có endpoint nào cho Breadth, Foreign Flow, Proprietary?
   - Cần test API calls nào?

3. **Output format:**
   - Giữ nguyên Markdown?
   - Thêm JSON cho automation?
   - Thêm Excel export?

**Khuyến nghị:** Bắt đầu với **Option C (Data Context Layer)** vì:
- Là nền tảng cho cả Module 1 và 2
- Các hàm `calc_trend_slope()`, `calc_rsi_regime()` dùng chung
- Một lần code, dùng nhiều nơi
