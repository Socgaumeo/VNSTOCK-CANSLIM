# 📋 KẾ HOẠCH TÁI CẤU TRÚC HỆ THỐNG CANSLIM SCANNER

> **Dựa trên:** Báo cáo Nghiên cứu & Thiết kế Hệ thống Giao dịch Định lượng Nâng cao
> **Ngày:** 27/11/2025
> **Mục tiêu:** Chuyển từ "phân tích điểm" sang "phân tích dòng chảy"

---

## 🎯 TỔNG QUAN KIẾN TRÚC MỚI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CANSLIM SCANNER v3.0                                 │
│                    "Data Flow & Context Analysis"                           │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        │                           │                           │
        ▼                           ▼                           ▼
┌───────────────┐         ┌───────────────┐         ┌───────────────┐
│  LAYER 1:     │         │  LAYER 2:     │         │  LAYER 3:     │
│  DATA CONTEXT │         │  ANALYSIS     │         │  SIGNAL       │
│  (Ngữ cảnh)   │         │  (Phân tích)  │         │  (Tín hiệu)   │
└───────────────┘         └───────────────┘         └───────────────┘
        │                           │                           │
   ┌────┴────┐              ┌───────┴───────┐           ┌───────┴───────┐
   │         │              │               │           │               │
   ▼         ▼              ▼               ▼           ▼               ▼
Module 0  Module 0       Module 1      Module 2     Module 5      Module 6
Config    DataCtx        Market        Sector       Smart         Entry
                         Timing        Rotation     Money         Point
                            │               │           │               │
                            └───────┬───────┘           └───────┬───────┘
                                    │                           │
                                    ▼                           ▼
                            ┌───────────────┐         ┌───────────────┐
                            │   Module 3    │         │   Module 7    │
                            │   CANSLIM     │         │   Risk Mgmt   │
                            │   Fundamental │         │   & Sizing    │
                            └───────────────┘         └───────────────┘
                                    │
                                    ▼
                            ┌───────────────┐
                            │   Module 4    │
                            │   SEPA/VCP    │
                            │   Patterns    │
                            └───────────────┘
```

---

## 📦 DANH SÁCH MODULES

| Module | Tên | Mô tả | Trạng thái |
|--------|-----|-------|------------|
| **0** | Config & Data Context | Cấu hình + Rolling Window + Vector hóa | ✅ Có, cần nâng cấp |
| **1** | Market Timing | Đèn giao thông + Distribution Days + FTD | ✅ Có, cần nâng cấp |
| **2** | Sector Rotation | RS Rating + Money Flow ngành | ✅ Có, cần nâng cấp |
| **3** | CANSLIM Fundamental | C (EPS Growth) + A (ROE, CAGR) | 🆕 Mới |
| **4** | SEPA/VCP Patterns | VCP + Volume Dry-up + Pocket Pivot | 🆕 Mới |
| **5** | Smart Money Flow | Khối ngoại + Tự doanh + CMF + AVWAP | 🆕 Mới |
| **6** | Support/Resistance & Trigger | Fractal + Breakout validation | 🆕 Mới |
| **7** | Entry/Exit & Risk | Stop Loss + Trailing + Pyramiding | 🆕 Mới |

---

## 🔧 MODULE 0: DATA CONTEXT LAYER (Nền tảng)

### Vấn đề hiện tại:
- Chỉ lấy `df.iloc[-1]` (snapshot)
- Không có "bộ nhớ" về quá khứ

### Cần bổ sung:

```python
class DataContextLayer:
    """
    Chuyển từ Scalar sang Time-Series
    Mọi chỉ báo đều có ngữ cảnh (context)
    """
    
    # 1. TREND SLOPE (Độ dốc xu hướng)
    def calc_trend_slope(self, ma_series, window=20):
        """
        Dùng Linear Regression để tính góc nghiêng của MA
        - slope > 0.5: Uptrend mạnh
        - slope ≈ 0: Sideway
        - slope < -0.5: Downtrend mạnh
        """
        
    # 2. PERCENTILE RANK (Vị thế tương đối)
    def calc_percentile_rank(self, price, window=50):
        """
        Giá đang ở vùng "Đắt" hay "Rẻ" so với N ngày qua
        Rank = Count(x_i < x_today) / N * 100
        """
        
    # 3. RSI REGIME (Chế độ RSI)
    def calc_rsi_regime(self, rsi_series, window=50):
        """
        RSI Rolling Min/Max trong 50 phiên
        - RSI_Min > 40: Bullish Regime
        - RSI_Max < 60: Bearish Regime
        """
        
    # 4. MACD IMPULSE SYSTEM
    def calc_macd_impulse(self, macd_hist):
        """
        Histogram đang tăng hay giảm?
        - Tăng: Không được Short
        - Giảm: Không được Long mới
        """
```

---

## 🚦 MODULE 1: MARKET TIMING (Cần nâng cấp)

### Hiện có:
- ✅ Price vs MA
- ✅ RSI, MACD, ADX
- ✅ Volume Profile (POC, VAH, VAL)
- ✅ Breadth (A/D ratio)
- ✅ Money Flow (basic)

### Cần bổ sung:

```python
class MarketTimingV3:
    """
    Traffic Light Model + Distribution Days + FTD
    """
    
    # 1. DISTRIBUTION DAY COUNTING
    def count_distribution_days(self, df, window=25):
        """
        Distribution Day = Giá giảm > 0.2% VÀ Volume > hôm trước
        
        Điều kiện:
        - < 3 ngày: XANH
        - 4-5 ngày: VÀNG
        - > 6 ngày: ĐỎ
        """
        
    # 2. FOLLOW-THROUGH DAY (FTD)
    def detect_follow_through_day(self, df):
        """
        Ngày "Bùng nổ theo đà" - Xác nhận đáy
        
        Điều kiện:
        - Ngày 4-10 từ đáy
        - Tăng > 1.25%
        - Volume > hôm trước
        """
        
    # 3. MARKET REGIME (Chế độ thị trường)
    def calc_market_regime(self, df):
        """
        Kết hợp tất cả để xác định:
        - ACCUMULATION (Tích lũy)
        - MARKUP (Tăng giá)
        - DISTRIBUTION (Phân phối)
        - MARKDOWN (Giảm giá)
        """
        
    # 4. TRAFFIC LIGHT với context
    def get_traffic_light(self):
        """
        XANH: Giá > MA20 > MA50 > MA200 + FTD + Dist < 3
        VÀNG: Dist 4-5 + Giá < MA20 nhưng > MA50
        ĐỎ: Dist > 6 + Giá < MA50 + Death Cross
        """
```

### Output mới Module 1:

```
═══════════════════════════════════════════════════════════════
📊 MARKET TIMING REPORT - 28/11/2025
═══════════════════════════════════════════════════════════════

🚦 TRAFFIC LIGHT: 🟢 XANH - TẤN CÔNG

📈 TREND CONTEXT:
   • MA50 Slope: +0.82 (Uptrend mạnh)
   • Percentile Rank: 92% (Vùng đắt)
   • RSI Regime: BULLISH (RSI_Min_50 = 52 > 40)
   • MACD Impulse: ▲ TĂNG (Không được Short)

📊 MARKET REGIME: MARKUP (Giai đoạn tăng giá)

⚠️ DISTRIBUTION DAYS: 2/25 phiên (An toàn)
   • 20/11: -0.45%, Vol +12%
   • 25/11: -0.32%, Vol +8%

✅ FOLLOW-THROUGH DAY: Có (Ngày 18/11, +1.8%, Vol +45%)

📊 VOLUME PROFILE:
   • POC: 1,650 | VA: 1,623-1,672
   • Giá hiện tại: 1,684 (ABOVE VA)
   • VP Support: 1,672, 1,650
   • VP Resistance: 1,700 (tâm lý)

💡 KHUYẾN NGHỊ: Full margin, Aggressive buying
   • Tỷ trọng: 80-100% Cổ phiếu
   • Focus: Mua breakout các Leader
```

---

## 🏭 MODULE 2: SECTOR ROTATION (Cần nâng cấp)

### Hiện có:
- ✅ Performance 1D/5D/1M/3M
- ✅ RS vs VNIndex
- ✅ Phase classification
- ✅ Volume Profile cơ bản

### Cần bổ sung:

```python
class SectorRotationV3:
    """
    IBD-style RS Rating + Cumulative Money Flow
    """
    
    # 1. RS RATING (IBD Style)
    def calc_rs_rating(self, stock_prices, index_prices):
        """
        RS Rating 1-99 dựa trên hiệu suất 12 tháng
        Weighted: Q1 (40%) + Q2 (30%) + Q3 (20%) + Q4 (10%)
        
        So sánh với toàn bộ cổ phiếu để rank percentile
        """
        
    # 2. SECTOR MONEY FLOW
    def calc_sector_money_flow(self, sector_stocks):
        """
        Tổng hợp:
        - Foreign Net Buy (Cumulative 20D)
        - Proprietary Net Buy
        - CMF của sector index
        """
        
    # 3. SECTOR ROTATION CLOCK
    def get_rotation_phase(self):
        """
        Early Cycle: Tài chính, BĐS dẫn đầu
        Mid Cycle: Công nghiệp, Nguyên vật liệu
        Late Cycle: Năng lượng, Hàng hóa
        Recession: Defensive (Tiện ích, Y tế)
        """
```

---

## 📊 MODULE 3: CANSLIM FUNDAMENTAL (MỚI)

```python
class CANSLIMFundamental:
    """
    Chữ C (Current Earnings) + Chữ A (Annual Earnings)
    Composite Score 100 điểm
    """
    
    # DATA SOURCE
    # vnstock: financial_flow(report_range='quarterly')
    
    # 1. CHỮ C - CURRENT QUARTERLY EARNINGS
    def calc_c_score(self, financials):
        """
        Tiêu chí:
        - EPS Growth YoY >= 25% (30đ)
        - Sales Growth >= 20% (15đ)
        - Gia tốc: Q này > Q trước (10đ)
        
        Cảnh báo:
        - EPS tăng nhưng Sales đi ngang -> Xào nấu BCTC
        """
        
    # 2. CHỮ A - ANNUAL EARNINGS
    def calc_a_score(self, financials):
        """
        Tiêu chí:
        - EPS CAGR 3 năm >= 25% (15đ)
        - ROE >= 17% (15đ)
        - Biên LN gộp mở rộng (10đ)
        - OCF > 0.8 * Net Income (10đ)
        """
        
    # 3. COMPOSITE FUNDAMENTAL SCORE
    def get_composite_score(self):
        """
        Total: 100 điểm
        Chỉ giao dịch khi Score > 75
        """

# BẢNG CHẤM ĐIỂM
SCORING_TABLE = {
    'eps_growth_q': {'weight': 30, 'thresholds': {'>50%': 30, '25-50%': 20, '<25%': 0}},
    'eps_growth_prev_q': {'weight': 10, 'thresholds': {'>25%': 10}},
    'acceleration': {'weight': 10, 'condition': 'Q này > Q trước'},
    'sales_growth': {'weight': 15, 'thresholds': {'>20%': 15}},
    'roe': {'weight': 15, 'thresholds': {'>25%': 15, '17-25%': 10}},
    'margin_expansion': {'weight': 10, 'condition': 'GPM mở rộng YoY'},
    'ocf_quality': {'weight': 10, 'condition': 'OCF > 0.8 * NI'},
}
```

---

## 📉 MODULE 4: SEPA/VCP PATTERNS (MỚI)

```python
class SEPAVCPDetector:
    """
    Phát hiện mô hình VCP và Volume Dry-up
    """
    
    # 1. VCP DETECTION (Volatility Contraction Pattern)
    def detect_vcp(self, df):
        """
        Tìm các đợt co hẹp (Contraction):
        - T1: Giảm 15-20% từ đỉnh
        - T2: Giảm 8-10%
        - T3: Giảm 2-4% (Pivot Point)
        
        Mỗi đợt sau phải nhỏ hơn đợt trước
        """
        
    # 2. VOLUME DRY-UP ALGORITHM
    def calc_volume_dryup(self, df):
        """
        Vol_SMA50 = MA(Volume, 50)
        
        Dry Day: Volume < 50% * Vol_SMA50
        Ultra Dry Day: Volume < 30% * Vol_SMA50
        
        Điều kiện VCP chuẩn:
        - Base >= 3 tuần
        - Dry Days > 40% số phiên trong base
        - Vol StdDev 10 phiên cuối giảm mạnh
        """
        
    # 3. POCKET PIVOT DETECTION
    def detect_pocket_pivot(self, df):
        """
        Tín hiệu mua sớm trong nền giá
        
        Điều kiện:
        - Giá tăng (không cần vượt đỉnh)
        - Volume > Max(Volume_Down) trong 10 ngày
        
        Hành động: Mua thăm dò 30% vị thế
        """
        
    # 4. BASE COUNTING
    def count_bases(self, df):
        """
        Đếm số Base đã hình thành
        - Base 1: An toàn nhất
        - Base 2: Vẫn OK
        - Base 3+: Rủi ro cao, tránh
        """
```

---

## 💰 MODULE 5: SMART MONEY FLOW (MỚI)

```python
class SmartMoneyAnalyzer:
    """
    Khối ngoại + Tự doanh + CMF + AVWAP
    """
    
    # 1. FOREIGN FLOW ANALYSIS
    def analyze_foreign_flow(self, df):
        """
        Cumulative Net Buy 20 ngày
        
        Tín hiệu:
        - Giá sideway + Cum. Net Buy tăng -> ACCUMULATION
        - Giá tăng + Cum. Net Buy giảm -> DISTRIBUTION
        """
        
    # 2. PROPRIETARY TRADING
    def analyze_prop_trading(self, df):
        """
        Confluence: Cả Foreign + Prop cùng mua 3 phiên
        -> Xác suất tăng > 80%
        """
        
    # 3. CHAIKIN MONEY FLOW (CMF)
    def calc_cmf(self, df, period=20):
        """
        MF_Multiplier = [(Close-Low) - (High-Close)] / (High-Low)
        MF_Volume = MF_Multiplier * Volume
        CMF = Sum(MF_Volume, 20) / Sum(Volume, 20)
        
        Xác nhận Breakout: CMF > 0.25
        Phân kỳ: Giá đỉnh mới, CMF đỉnh thấp hơn -> BÁN
        """
        
    # 4. ANCHORED VWAP
    def calc_anchored_vwap(self, df, anchor_date):
        """
        VWAP từ một sự kiện quan trọng:
        - Ngày BCTC
        - Ngày đáy thị trường
        - Ngày đầu năm
        
        Pullback về AVWAP = Điểm mua an toàn
        """
```

---

## 🎯 MODULE 6: SUPPORT/RESISTANCE & TRIGGER (MỚI)

```python
class SRTriggerEngine:
    """
    Fractal Pivots + Breakout Validation
    """
    
    # 1. FRACTAL PIVOT POINTS
    def calc_fractal_pivots(self, df):
        """
        Bill Williams Fractal (5 nến):
        - Đỉnh Fractal: High[2] > High[0,1,3,4]
        - Đáy Fractal: Low[2] < Low[0,1,3,4]
        
        Clustering: Nhiều Fractal cùng vùng -> Major Level
        """
        
    # 2. ALGORITHMIC ZONES
    def calc_sr_zones(self, df):
        """
        Kết hợp:
        - Fractal Pivots
        - Volume Profile HVN/LVN
        - Round Numbers (10, 20, 50, 100...)
        - Unfilled Gaps
        """
        
    # 3. BREAKOUT VALIDATION
    def validate_breakout(self, df, resistance):
        """
        Điều kiện Breakout hợp lệ:
        1. Biên độ: Close > Resistance + 1%
        2. Volume: > 150% * Vol_MA20
        3. Thời gian: Giữ trên 2 phiên (T+2.5)
        4. Chỉ báo: RSI > 60, ADX tăng, CMF > 0.1
        """
        
    # 4. RETEST STRATEGY
    def detect_retest_setup(self, df, broken_level):
        """
        Breakout xong quay lại test
        
        Điều kiện mua:
        - Giá chạm hỗ trợ (đỉnh cũ)
        - Volume thấp (Dry-up)
        - Nến rút chân (Pinbar)
        """
```

---

## 🛡️ MODULE 7: RISK MANAGEMENT & SIZING (MỚI)

```python
class RiskManager:
    """
    Stop Loss + Trailing + Pyramiding
    """
    
    # 1. INITIAL STOP LOSS
    def calc_initial_stop(self, entry_price, df):
        """
        Options:
        - Dưới đáy nến Breakout
        - Dưới MA20
        - ATR-based: Entry - 2 * ATR(14)
        """
        
    # 2. TRAILING STOP
    def calc_trailing_stop(self, highest_price, df):
        """
        Chandelier Exit: Highest - 3 * ATR
        
        Hoặc:
        - MA20 trailing
        - Parabolic SAR
        """
        
    # 3. POSITION SIZING
    def calc_position_size(self, capital, risk_pct, entry, stop):
        """
        Risk Amount = Capital * Risk%
        Position Size = Risk Amount / (Entry - Stop)
        
        Max 2% risk per trade
        Max 6% risk per sector
        """
        
    # 4. PYRAMIDING RULES
    def get_pyramid_plan(self):
        """
        Mua theo bậc thang:
        - 50% tại Pivot Point
        - 30% khi test thành công
        - 20% khi vượt đỉnh tiếp theo
        
        Chỉ pyramid khi vị thế cũ có lãi
        """
```

---

## 🔄 WORKFLOW TỔNG THỂ

```
                    ┌────────────────────────┐
                    │   START: Daily Scan    │
                    └───────────┬────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │  MODULE 0: Load Data   │
                    │  + Build Context Layer │
                    └───────────┬────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │  MODULE 1: Market      │
                    │  Timing (Traffic Light)│
                    └───────────┬────────────┘
                                │
            ┌───────────────────┼───────────────────┐
            │                   │                   │
            ▼                   ▼                   ▼
        🟢 XANH            🟡 VÀNG             🔴 ĐỎ
     Full Attack         Defensive           Cash Only
            │                   │                   │
            ▼                   ▼                   │
    ┌───────────────┐   ┌───────────────┐          │
    │ MODULE 2:     │   │ MODULE 2:     │          │
    │ Full Sector   │   │ Defensive     │          │
    │ Analysis      │   │ Sectors Only  │          │
    └───────┬───────┘   └───────┬───────┘          │
            │                   │                   │
            ▼                   ▼                   │
    ┌───────────────┐   ┌───────────────┐          │
    │ MODULE 3:     │   │ Skip Module 3 │          │
    │ CANSLIM       │   │ (No new buys) │          │
    │ Fundamental   │   └───────────────┘          │
    └───────┬───────┘                              │
            │                                      │
            ▼                                      │
    ┌───────────────┐                              │
    │ MODULE 4:     │                              │
    │ SEPA/VCP      │                              │
    │ Pattern Scan  │                              │
    └───────┬───────┘                              │
            │                                      │
            ▼                                      │
    ┌───────────────┐                              │
    │ MODULE 5:     │                              │
    │ Smart Money   │                              │
    │ Confirmation  │                              │
    └───────┬───────┘                              │
            │                                      │
            ▼                                      │
    ┌───────────────┐                              │
    │ MODULE 6:     │                              │
    │ Entry Trigger │                              │
    │ Validation    │                              │
    └───────┬───────┘                              │
            │                                      │
            ▼                                      │
    ┌───────────────┐                              │
    │ MODULE 7:     │◄─────────────────────────────┘
    │ Risk Mgmt     │   (Tính sizing cho cả Buy/Sell)
    │ Position Size │
    └───────┬───────┘
            │
            ▼
    ┌───────────────────────────────────────────────┐
    │              FINAL OUTPUT                     │
    │  • Danh sách BUY với Entry, Stop, Target      │
    │  • Danh sách SELL với Exit reasons            │
    │  • Portfolio Allocation                       │
    └───────────────────────────────────────────────┘
```

---

## 📅 ROADMAP TRIỂN KHAI

| Phase | Modules | Thời gian | Ưu tiên |
|-------|---------|-----------|---------|
| **Phase 1** | Module 0 (Data Context) | 1 ngày | 🔴 Critical |
| **Phase 2** | Module 1 v3 (Market Timing nâng cấp) | 1 ngày | 🔴 Critical |
| **Phase 2** | Module 2 v3 (Sector Rotation nâng cấp) | 1 ngày | 🔴 Critical |
| **Phase 3** | Module 3 (CANSLIM Fundamental) | 2 ngày | 🟡 High |
| **Phase 4** | Module 4 (SEPA/VCP) | 2 ngày | 🟡 High |
| **Phase 5** | Module 5 (Smart Money) | 1 ngày | 🟡 High |
| **Phase 6** | Module 6 (S/R & Trigger) | 1 ngày | 🟢 Medium |
| **Phase 7** | Module 7 (Risk Mgmt) | 1 ngày | 🟢 Medium |
| **Phase 8** | Integration & Testing | 2 ngày | 🔴 Critical |

**Tổng:** ~12-14 ngày

---

## ✅ ACTION ITEMS NGAY

### Module 1 - Cần sửa ngay:

1. **Thêm Distribution Day counting**
2. **Thêm Follow-Through Day detection**
3. **Thêm Trend Slope (Linear Regression)**
4. **Thêm RSI Regime analysis**
5. **Cải thiện Traffic Light logic**

### Module 2 - Cần sửa ngay:

1. **Thêm RS Rating IBD-style**
2. **Thêm Cumulative Money Flow**
3. **Thêm Sector Rotation Clock**

---

## 📝 GHI CHÚ QUAN TRỌNG TỪ TÀI LIỆU

> "Sự thất bại của phân tích đơn nến (Single-Candle Analysis)"
> → Mọi tín hiệu phải có CONTEXT từ quá khứ

> "Một cây nến Pinbar tại đỉnh của xu hướng tăng kéo dài 6 tháng 
> mang ý nghĩa hoàn toàn khác với Pinbar tại đáy điều chỉnh 20%"
> → Position matters more than pattern

> "Khi độ dốc của MA50 bắt đầu phẳng lại sau một đợt tăng dài, 
> đó là dấu hiệu sớm của quá trình Phân phối"
> → Trend Slope là leading indicator

> "RSI có thể duy trì trên 70 trong hàng tháng trời trong Super Uptrend"
> → RSI Regime > RSI Level

> "Volume Dry-up là nghệ thuật của sự cạn kiệt nguồn cung"
> → VCP không có Volume Dry-up là giả

---

**Bạn muốn bắt đầu từ module nào trước?**
